function Authentication(){}

var nones
Authentication.prototype.userLogin = function(){
		//$.mobile.changePage('#navigation')

		var _userName = $("#login_username").val()
		var _userPass = $("#login_password").val()

		$.ajax({
			type: "POST",
			url: app.WS_URL+"session",
			dataType: 'json',
			data: '{ "username": "'+_userName +'", "password": "'+_userPass+'"}' ,
			contentType: "application/json; charset=utf-8",
			success:  function (response){
 
				
				if(response.Success == true ){
					console.log("--- User loged IN ---")
					app.authentication.successLogin()
					//$.mobile.changePage('#navigationXX');

				}else if(response.Success == false ){

					app.authentication.failedLogin()
					//$.mobile.changePage('#login');
				}else{
					console.log("no leo")
				}
				console.log(response)
				nones = response
			},
			error: function (response) {
				console.log("no")//response)
				console.log(response)
				app.authentication.failedLogin()
			}
		});
}
Authentication.prototype.failedLogin = function(){
	$("#login_username").val("")
	$("#login_password").val("")
	alert("Wrong username or password.\nPlease Try Again")
}
Authentication.prototype.successLogin = function() {
	localStorage.setItem("userLoggedSuccess","true")
	$.mobile.changePage('#navigationScreen');
	console.log("todo OK navigation")
};

Authentication.prototype.veriftyPreviousLogins = function() {

 
	var status = localStorage.getItem("userLoggedSuccess");
	if ( status == "true") {
		app.authentication.successLogin()
	}else{
		$.mobile.changePage('#login');
		console.log("reenvia al login")
	}
	
}


Authentication.prototype.FBlogin = function(){
	// $.mobile.changePage('#navigation')
}

//Basic User Account: testuser@bluetechnologygroup.com(password: testing123)
//Admin User Account:  adminuser@bluetechnologygroup.com(password: testing123)
