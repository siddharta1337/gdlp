// JavaScript Document
var GoodLoop = function(){}

GoodLoop.prototype.WS_URL = "http://www.goodloop.org/api/"



GoodLoop.prototype.init = function(){
	
	/// inicializa las variables del sistema
	this.authentication = new Authentication()
	this.navigation = new Navigation()

	this.authentication.veriftyPreviousLogins()

}