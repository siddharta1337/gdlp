// JavaScript Document
function Navigation(){}

Navigation.prototype.go = function(_pageID) {
 
	$.mobile.changePage("#"+_pageID);
};