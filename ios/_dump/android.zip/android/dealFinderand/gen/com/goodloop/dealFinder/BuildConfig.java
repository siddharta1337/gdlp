/** Automatically generated file. DO NOT MODIFY */
package com.goodloop.dealFinder;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}